# SnakeGameHtml
The classic game snake developed with HTML and JavaScript
